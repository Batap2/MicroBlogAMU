pour lancer le serveur : src/Server.java
pour lancer le client : src/ClientMicroblogamu.java
